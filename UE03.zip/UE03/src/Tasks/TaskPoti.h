#ifndef TASK_POTI_H
#define TASK_POTI_H

void TaskPoti (void);

#endif
