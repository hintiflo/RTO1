#ifndef __TESTTASK
#define __TESTTASK


void TaskA (void);

void TaskB (void);

void TaskC (void);

#endif //__TESTTASK