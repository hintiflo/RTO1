void TaskA (void) 
{
				FillTaskA();
		while (1) 
		{

		}
}

void TaskB (void) 
{		
				FillTaskB();
		while (1) 
		{ 

		}
}

void TaskC (void) 
{	
					FillTaskC();
		while (1) 
		{ 

		}
}
