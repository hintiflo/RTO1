#ifndef TASK_MANDELBROT_H
#define TASK_MANDELBROT_H

void TaskMandelbrot (void);

#endif

