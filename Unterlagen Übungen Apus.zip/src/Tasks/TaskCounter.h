#ifndef TASK_COUNTER_H
#define TASK_COUNTER_H

void TaskCounter (void);

#endif

