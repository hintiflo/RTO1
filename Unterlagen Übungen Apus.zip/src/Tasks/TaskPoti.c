#include "BSP/TftDisplay.h"
#include "StdDef.h"
#include "TaskPoti.h"


void TaskPoti (void)
{
	Tft_DrawString(10, 18+4*24, "Poti ");	
}
