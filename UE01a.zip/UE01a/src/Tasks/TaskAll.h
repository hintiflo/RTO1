#ifndef TASK_ALL_H
#define TASK_ALL_H

#include "TaskWatch.h"
#include "TaskMandelbrot.h"
#include "TaskKey.h"
#include "TaskCounter.h"
#include "TaskPoti.h"
#include "TaskLed.h"

#endif
