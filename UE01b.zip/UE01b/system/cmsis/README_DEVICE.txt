The system_stm32f0xx.c file is from stsw-stm32048.zip, the folder:

	STM32F0xx_StdPeriph_Lib_V1.3.1/Libraries/CMSIS/Device/ST/STM32F0xx/Source/Templates
	
The vectors_stm32f0xx.c file was created to conform with the assembly files 
gc_ride7/startup_stm32f0xx.s.